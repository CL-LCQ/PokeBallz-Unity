using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_TwitterPost : FsmStateAction {
		
		public FsmString message;
		public FsmString url;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}


			IOSSocialManager.OnTwitterPostResult += HandleOnTwitterPostResult;
			IOSSocialManager.instance.TwitterPost(message.Value, url.Value, texture.Value as Texture2D);
			
		}

		void HandleOnTwitterPostResult (ISN_Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}
			
			IOSSocialManager.OnTwitterPostResult -= HandleOnTwitterPostResult;
			Finish();
		}

		public override void Reset() {
			base.Reset();
			message   = "Message Text";
			
		}
		
	}
}



