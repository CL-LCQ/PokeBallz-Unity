﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Amazon Native - Billing v2.0")]
	public class AMN_GetProductInfoById : FsmStateAction {
		
		public FsmString productSKU;
		public FsmEvent successEvent;
		public FsmEvent failedEvent;

		public FsmString sku;
		public FsmString productType;
		public FsmString price;
		public FsmString title;
		public FsmString description;
		public FsmString smallIconUrl;

		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if (SA_AmazonBillingManager.instance.availableItems.Count == 0) {
				SA_AmazonBillingManager.instance.OnGetProductDataReceived += OnGetProductDataReceived;
				SA_AmazonBillingManager.instance.Initialize ();
			} else {
				OnGetProductDataSuccess();
			}
		}
		
		void OnGetProductDataReceived (AMN_GetProductDataResponse result) {
			SA_AmazonBillingManager.instance.OnGetProductDataReceived -= OnGetProductDataReceived;
			if (result.isSuccess) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failedEvent);
			}
			
			Finish();
		}

		void OnGetProductDataSuccess ()	{
			SA_AmazonProductData product = SA_AmazonBillingManager.instance.availableItems [productSKU.Value];
			if(product != null) {
				sku.Value = product.Sku;
				productType.Value = product.ProductType;
				price.Value = product.Price;
				title.Value = product.Title;
				description.Value = product.Description;
				smallIconUrl.Value = product.SmallIconUrl;

				Fsm.Event(successEvent);
			}
			else {
				Fsm.Event(failedEvent);
			}

			
			Finish();
		}
	}
}

