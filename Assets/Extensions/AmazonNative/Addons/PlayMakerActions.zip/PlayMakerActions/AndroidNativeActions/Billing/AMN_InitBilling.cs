﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Amazon Native - Billing v2.0")]
	public class AMN_InitBilling : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failedEvent;
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			SA_AmazonBillingManager.instance.OnGetProductDataReceived += OnGetProductDataReceived;
			SA_AmazonBillingManager.instance.Initialize ();
		}
		
		void OnGetProductDataReceived (AMN_GetProductDataResponse result) {
			SA_AmazonBillingManager.instance.OnGetProductDataReceived -= OnGetProductDataReceived;
			if (result.isSuccess) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failedEvent);
			}
			
			Finish();
		}
	}
}

