﻿using UnityEngine;
using System.Collections;
using System;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Amazon Native - GameCircle")]
	public class AMN_LoadGCAchievements : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public FsmString reason;

		public FsmString title;
		public FsmString id;
		public FsmString description;
		public FsmFloat progress;
		public FsmInt pointValue;
		public FsmBool isHidden;
		public FsmBool isUnlocked;
		public FsmInt position;

		public override void OnEnter() {						
			SA_AmazonGameCircleManager.instance.OnRequestAchievementsReceived += OnRequestAchievementsReceived;
			SA_AmazonGameCircleManager.instance.RequestAchievements ();
		}
		
		void OnRequestAchievementsReceived(AMN_RequestAchievementsResult result) {
			if (result.isSuccess) {
				title.Value 		= result.AchievementList[0].Title;
				id.Value 			= result.AchievementList[0].Id;
				description.Value	= result.AchievementList[0].Description;
				progress.Value 		= result.AchievementList[0].Progress;
				pointValue.Value 	= result.AchievementList[0].PointValue;
				isHidden.Value 		= result.AchievementList[0].IsHidden;
				isUnlocked.Value 	= result.AchievementList[0].IsUnlocked;
				position.Value 		= result.AchievementList[0].Position;

				Fsm.Event(successEvent);
			} else {
				reason.Value = result.Error;

				Fsm.Event(failEvent);
			}

			Finish ();
		}
	}
}
