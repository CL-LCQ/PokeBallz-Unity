﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Amazon Native - GameCircle")]
	public class AMN_SubmitLeaderboardScore : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;

		public FsmInt score;
		public FsmString leaderb_Id;

		public FsmString reason;
		public FsmString LeaderboardID;
		
		public override void OnEnter() {
			SA_AmazonGameCircleManager.instance.OnSubmitLeaderboardReceived += OnSubmitLeaderboardReceived;
			SA_AmazonGameCircleManager.instance.SubmitLeaderBoardProgress (leaderb_Id.Value, score.Value);
		}

		void OnSubmitLeaderboardReceived(AMN_SubmitLeaderboardResult result) {
			if (result.isSuccess) {				
				LeaderboardID.Value = result.LeaderboardID;
				
				Fsm.Event(successEvent);
			} else {
				reason.Value = result.Error;				
				LeaderboardID.Value = result.LeaderboardID;
				
				Fsm.Event(failEvent);
			}
			
			Finish();
		}
	}
}

